import os
from pathlib import Path
from flask import Flask
from .extensions import db, jwt, bcrypt


def create_app():
    app = Flask(__name__)

    # -------------------------------------------------
    # Caminho do banco
    # -------------------------------------------------
    BASE_DIR = Path(__file__).resolve().parent.parent
    DB_PATH = BASE_DIR / "data" / "4she.db"
    DB_PATH.parent.mkdir(exist_ok=True)

    # -------------------------------------------------
    # Configuração
    # -------------------------------------------------
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
        "DATABASE_URL", f"sqlite:///{DB_PATH}"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["JWT_SECRET_KEY"] = os.getenv(
        "JWT_SECRET", "dev-secret-nao-use-em-producao"
    )
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = False  # ou timedelta(days=30)

    # -------------------------------------------------
    # Liga extensões ao app
    # -------------------------------------------------
    db.init_app(app)
    jwt.init_app(app)
    bcrypt.init_app(app)

    # Registra os models no metadata do SQLAlchemy
    from . import models  # noqa: F401

    # -------------------------------------------------
    # Registra blueprints (rotas)
    # -------------------------------------------------
    # from .routes.auth     import auth_bp
    # from .routes.boards   import boards_bp
    # from .routes.threads  import threads_bp
    # from .routes.comments import comments_bp

    # app.register_blueprint(auth_bp,     url_prefix="/api/auth")
    # app.register_blueprint(boards_bp,   url_prefix="/api/boards")
    # app.register_blueprint(threads_bp,  url_prefix="/api/threads")
    # app.register_blueprint(comments_bp, url_prefix="/api/threads")
    # # healthcheck
    @app.route("/api/health")
    def health():
        return {"ok": True, "ts": __import__("time").time()}

    return app